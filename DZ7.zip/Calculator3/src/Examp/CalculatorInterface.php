<?php

namespace App\Examp;

interface CalculatorInterface
{
    public function sum(float $a, float $b): float;
}
